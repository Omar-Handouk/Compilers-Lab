import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;

public class Test {

    public static void main(String[] args) {

        String[] testCases = new String[]{
                "0011001",
                "1110111001",
                "1111011011",
                "100011",
                "0010111011",
                "100011100",
                "1111101",
                "0100101",
                "00010001101",
                "10100111101",
                "111010000",
                "011010101"};

        for (String s : testCases) {
            task5Lexer lexer = new task5Lexer(CharStreams.fromString(s));
            task5Parser parser = new task5Parser(new CommonTokenStream(lexer));

            parser.start();
            System.out.println();
        }
    }
}
