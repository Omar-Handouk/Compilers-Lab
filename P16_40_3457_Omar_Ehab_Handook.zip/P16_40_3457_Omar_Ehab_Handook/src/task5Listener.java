// Generated from /home/omar-handouk/IdeaProjects/P16_40_3457_Omar_Ehab_Handook/src/task5.g4 by ANTLR 4.9.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link task5Parser}.
 */
public interface task5Listener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link task5Parser#start}.
	 * @param ctx the parse tree
	 */
	void enterStart(task5Parser.StartContext ctx);
	/**
	 * Exit a parse tree produced by {@link task5Parser#start}.
	 * @param ctx the parse tree
	 */
	void exitStart(task5Parser.StartContext ctx);
}